console.log("You'll need to put valid credentials into ga_details.js");

var _gaq = _gaq || [];
_gaq.push(['_setAccount', 'UA-XXXXXX-X']);
_gaq.push(['_setDomainName', 'example.com']);
_gaq.push(['_trackPageview']);
