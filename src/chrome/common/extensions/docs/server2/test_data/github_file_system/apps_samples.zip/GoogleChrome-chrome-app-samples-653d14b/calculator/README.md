# Calculator

A sample application that provides a simple calculator. Supports basic operations
such as addition, multiplication, subtraction and division.

This sample also incorporates an MVC-style structure and requires jQuery for
DOM manipulation.

## APIs

* [Runtime](http://developer.chrome.com/trunk/apps/app.runtime.html)
* [Window](http://developer.chrome.com/trunk/apps/app.window.html)

---
Last updated: 2012-08-14 by miu
