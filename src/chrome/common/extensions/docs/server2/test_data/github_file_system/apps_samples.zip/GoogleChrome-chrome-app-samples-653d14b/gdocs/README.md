# Google Docs Platform Client

Uses the `chrome.experimental.identity.getAuthToken()` API to do OAuth2 and
access the Google Docs API. Drag n' Drop files from the desktop onto the app.
