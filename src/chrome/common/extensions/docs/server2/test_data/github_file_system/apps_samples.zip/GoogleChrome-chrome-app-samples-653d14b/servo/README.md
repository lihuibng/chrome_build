This app displays a slider that, when dragged, causes a servo attached to an Arduino to move. The Arduino sketch is included and should be uploaded to the Arduino.

