# Telnet in your teh browser!

Try connecting to aardmud.org on port 4000.

* TCP client
* DNS resolver
* ANSI color renderer

## Credits

Networking stuff, ANSI colors by Boris Smus.
Terminal by Eric Bidelman: http://www.htmlfivewow.com/demos/terminal/terminal.html
