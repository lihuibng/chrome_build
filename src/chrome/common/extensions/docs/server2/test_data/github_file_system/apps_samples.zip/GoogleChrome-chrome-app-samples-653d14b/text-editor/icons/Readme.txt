The icons in this project are awesome and come from http://www.silvestre.com.ar/.
