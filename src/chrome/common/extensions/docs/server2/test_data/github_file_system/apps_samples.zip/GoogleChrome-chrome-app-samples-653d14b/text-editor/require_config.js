      var require = {
          baseUrl: window.location.protocol + "//" + window.location.host + window.location.pathname.split("/").slice(0, -1).join("/"),
          paths: {
              ace: "lib/ace"
          }
      };
