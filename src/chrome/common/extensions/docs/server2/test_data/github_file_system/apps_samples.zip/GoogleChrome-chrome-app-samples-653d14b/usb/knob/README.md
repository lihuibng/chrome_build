NOTE
----
This demo interfaces with a Griffin PowerMate device, reading its position and displaying it via a Chrome logo. It does not currently work on Mac OS X, since on that platform the OS claims the PowerMate is an HID device, and does not allow raw USB access to it.
